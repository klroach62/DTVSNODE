
//  host: "davey-tree-project-klroach62.c9users.io",
var mySqlConnectionString = {

    connectionString: {
        dev: {
            host: "us-cdbr-azure-east-c.cloudapp.net",
            user: "b85dcac7e0f1a5",
            password: "d4137485",
            database: "DaveyTree"
        },
        prod: {
            host: "us-cdbr-azure-east-c.cloudapp.net",
            user: "b85dcac7e0f1a5",
            password: "d4137485",
            database: "DaveyTree"
        }
    }

};
exports.mySqlConnectionString = mySqlConnectionString;
