var connProvider = require("./mySqlConnectionP");
var connection = connProvider.mysqlConnectionP.getSqlConn();

var getSite1 = function (myid, callback) {
    var TreeAddress = [];
    var sql = 'SELECT * FROM trees where id=' + myid;

    if (connection) {
        connection.query(sql, function (err, rows, fields) {
            rows.forEach(function (row) {
                TreeAddress.push(row);
            });
            callback(TreeAddress);
        });
    }
};
var getSites = function (callback) {
    var TreeAddress = [];
    var sql = 'SELECT * FROM trees';

    if (connection) {
        connection.query(sql, function (err, rows) {
            rows.forEach(function (row) {
                TreeAddress.push(row);
            });
            callback(TreeAddress);
        });
    }
};

var getDupSites = function (callback) {
    var TreeAddress = [];
    var sql = 'SELECT distinct a.* FROM trees a INNER JOIN trees b ON a.address = b.address and a.Street=b.Street and a.site = b.site WHERE a.ID <> b.ID';
    if (connection) {
        connection.query(sql, function (err, rows, fields) {
            rows.forEach(function (row) {
                TreeAddress.push(row);
            });
            callback(TreeAddress);
        });
    }
};
var updateSite = function (id, PASSbody, res) {
    var body = JSON.parse(PASSbody);
    if (connection) {
        var query = connection.query("UPDATE trees SET Address = ?, Street = ?, Side = ?, Site = ?, Species = ?, `Condition` = ?, DBH = ? WHERE ID = ?", [body.Address, body.Street, body.Side, body.Site, body.Species, body.Condition, body.DBH, id]);
    };
};


module.exports = {
    getSite1: getSite1,
    getSites: getSites,
    getDupSites: getDupSites,
    updateSite: updateSite
};