var express = require('express');
var router = express.Router();

// middleware specific to this router
router.use(function timeLog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
});
/* GET home page. */
// index page 
router.get('/', function (req, res) {
    res.render('pages/index');
});

router.get('/TreeListMain', function (req, res, next) {

    var getTrees = require('../dao/dupTrees.js');
    getTrees.getSites(function (TreeAddress) {
        res.render('pages/TreeListMain', {
            TreeAddress: TreeAddress
        });
    });

});


router.get('/TreeList', function (req, res, next) {

    var getTrees = require('../dao/dupTrees.js');
    getTrees.getDupSites(function (TreeAddress) {
        res.render('pages/TreeList', {
            TreeAddress: TreeAddress
        });
    });

});

router.get('/SiteDetails/:id', function (req, res, next) {
    var getTrees = require('../dao/dupTrees.js');

    getTrees.getSite1(req.params.id, function (TreeAddress) {
        res.render('pages/SiteDetails', {
            TreeAddress: TreeAddress
        });
    });


});

router.post('/SiteDetails', function (req, res) {
    var getTrees = require('../dao/dupTrees.js');

    var arraybody = JSON.stringify(req.body);
    getTrees.updateSite(req.body.id, arraybody, function (res) {

    });
    res.redirect('/TreeListMain');

});

module.exports = router;
